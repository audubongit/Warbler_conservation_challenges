################################################################################################################### 
# Script to overlay conservation challenges layers with weekly abundance data from eBird Status models developed by 
# Cornell Lab of Ornithology. 
# Outputs: weekly abundance and percent of population exposed to conservation challenges summarized into hexagons
# Code developed by L. Taylor and E. Knight, 2020 - 2023. 
###################################################################################################################

library(raster)
library(data.table)
library(dplyr)
library(tidyr)
library(sf)
library(fasterize)
library(stringr)

# directories
year <- 2021
setwd('Z:/5_MigratoryBirdInitiative/')
stmdir <- paste0('Z:/10_Data/eBird/STEM/', year, '/')
spp_dir <- 'Migration_Data/Species/'
thr_dir <- 'CC_Data/Processed/'
outdir <- 'Migration_Data/Species/'

# species list
spp_list <- data.frame(species_code = c('amered'), species_name = c('American Redstart')) # list species to process

# get list of conservation challenge layers
thr_files <- dir(thr_dir, pattern='Final.tif$', recursive=TRUE, full.names=TRUE)
thr_names <- str_split_fixed(thr_files, '/', 3) %>% as.data.frame(.) %>%
  mutate(V3 = paste0('X', V3)) %>% pull(V3)

# summary geography
hex_size <- 50
hex_poly <- st_read(paste0('GIS_Data/Hexagon Grids/hex_grid_', hex_size, 'k.shp'), quiet=TRUE)
hex_raster_file <- paste0('GIS_Data/Hexagon Grids/hex_grid_', hex_size, 'k_aligned_to_ebirdst.tif')


# clean up environment
pre_loop <- ls()

# create function
summarize_CC <- function(i, spp_list, overwrite=TRUE) { 
  
  start.species <- Sys.time()
  
  # species to work on
  spp_code <- spp_list$species_code[i]
  spp_name <- spp_list$species_name[i]
  cat(spp_name, '-', i, 'of', nrow(spp_list), '\n')
  
  # species summary files
  spp_out_csv <- paste0(outdir, spp_code, '/', spp_code, '_summary_threats_hex', hex_size, 'k.csv')
  spp_out_shp <- paste0(outdir, spp_code, '/', spp_code, '_summary_threats_hex', hex_size, 'k.shp')
  
  if(!file.exists(spp_out_csv)){
    
    # species abundance data
    spp_file <- dir(paste0(stmdir, spp_code, '/weekly/'),
                    pattern=paste0(spp_code, '.*_abundance_median_3km_', year, '.tif$'),
                    recursive=TRUE, full.names=TRUE)
    
    # get extents to match
    spp_r <- stack(spp_file)
    hex_r <- crop(extend(raster(hex_raster_file), spp_r), spp_r)
    thr_r <- crop(extend(stack(thr_files), spp_r), spp_r)
    names(thr_r) <- thr_names
    
    # calculate abundance sum and average within each hex
    print('Calculating abundance isopleths')
    abund_year_df <- NULL

    for (w in 1:52) {

      # stack and summarize
      abund_summary <- as.data.frame(stack(c(hex_r, spp_r[[w]]))) %>%
        rename_at(1:2, ~c('hex_id', 'abund_total')) %>%
        filter(!is.na(hex_id) & !is.na(abund_total)) %>%
        group_by(hex_id) %>%
        summarize(abund_sum=sum(abund_total, na.rm=TRUE),
                  abund_avg=mean(abund_total, na.rm=TRUE)) %>%
        filter(abund_avg > 0)

      # calculate isopleths for abund_avg
      vals <- sort(pull(abund_summary, abund_avg), decreasing=TRUE)
      sum <- sum(vals, na.rm=TRUE)

      # find break points where isopleths are reached
      brks <- NULL
      for (i in seq(0.1, 1, 0.1)) {
        vol <- 0
        for (v in 1:length(vals)) {
          if (vol < sum*i) { vol <- vol + vals[v] }
          else break }
        brks <- c(brks, vals[v])
      }

      # cut values based on isopleth breaks
      brks <- unique(c(brks, max(vals)))
      if(length(brks) > 1){
        abund_summary <- mutate(abund_summary, abund_iso=cut(abund_avg, breaks=brks, labels=FALSE, include.lowest=TRUE))
      }else{
        abund_summary <- mutate(abund_summary, abund_iso=1)
      }

      abund_summary <- abund_summary %>%
        mutate(week=w)

      abund_year_df <- rbind(abund_year_df, abund_summary)

    }
    
    
    # Calculate conservation challenges
    # stack and summarize
    print('Calculating conservation challenges')
    cc_year_df <- NULL
    
    for (w in 1:52) { 
      print(paste0('week ', w))
      cc_week_df <- as.data.frame(stack(c(spp_r[[w]], hex_r, thr_r))) %>%
        rename_at(1:2, ~c('abund', 'hex_id')) %>%
        filter(!is.na(hex_id) & abund > 0) %>%
        mutate(across(3:ncol(.), ~.x*abund)) %>%
        group_by(hex_id) %>%
        summarize(across(where(is.numeric), ~sum(.x, na.rm=TRUE))) %>%
        mutate(across(3:ncol(.), ~.x/abund), week=w)
      cc_year_df <- rbind(cc_year_df, cc_week_df)
    }
    
    
    # Combine abundance and conservation challenges
    all_df <- inner_join(abund_year_df, cc_year_df, by=c('hex_id', 'week')) %>%
      mutate(week_date=as.Date(paste(1000, week, 1, sep='-'), '%Y-%U-%u')) %>%
      select(hex_id, week, week_date, abund_sum, abund_avg, abund_iso, starts_with('X')) %>%
      rename_at(7:ncol(.), ~gsub('_Current.*|_Future.*', '', .)) %>%
      rename_at(7:ncol(.), ~gsub('[a-z]', '', .))

    year_sf <- right_join(hex_poly, all_df, by='hex_id')
    
    # save outputs
    fwrite(all_df, spp_out_csv)
    st_write(year_sf, spp_out_shp, quiet=TRUE, append=FALSE, abbreviate_shapefile_names=FALSE)
    
  }
  
  # time difference
  cat('\n'); print(Sys.time() - start.species); cat('\n')
  rm(list=setdiff(ls(), c('pre_loop', pre_loop))); gc()
  
}


# run function in a loop
for (i in 1:nrow(spp_list)) { try(summarize_CC(i, spp_list, overwrite=TRUE)) }



