################################################################################################################### 
# Script to summarize and plot weekly conservation challenges exposures (calculated in script 1) across hexagons.
# Outputs: weekly percent of population exposed to conservation challenges in tabular and graphical format.
# Code developed by E. Knight and L. Taylor, 2021 - 2023. 
###################################################################################################################

library(data.table)
library(readxl)
library(plyr)
library(dplyr)
library(tidyr)
library(sf)
library(ggplot2)
library(lubridate)

# directories
setwd('Z:/5_MigratoryBirdInitiative/')
boxdir_warblers <- paste0("D:/Users/masmith/Box/-.Science Team shared/2_Projects/9_MigratoryBirdInitiative/Conservation Challenges/3. CC Exposure Paper/Species Threat Matrix/")
hex_size <- '50k'

# species list

#run single species
#spp_list <- data.frame(species_code = c('conwar'), species_name = c('Connecticut Warbler')) # list species to process
#run all species
spp_list <- data.frame(species_code = c('amered','babwar','bawwar','bkbwar','bkpwar','btbwar','btnwar','btywar','buwwar','camwar','canwar','cerwar','chswar',
                                        'colwar','comyel','conwar','gchwar','gowwar','grawar','herwar','hoowar','kenwar','kirwar','louwat','lucwar','macwar',
                                        'magwar','mouwar','naswar','norpar','norwat','orcwar','ovenbi1','paired','palwar','pinwar','prawar','prowar','refwar',
                                        'swawar','tenwar','towwar','virwar','wlswar','woewar1','yelwar','yerwar','yetwar'),
                        species_name = c("American Redstart","Bay-breasted Warbler","Black-and-white Warbler","Blackburnian Warbler","Blackpoll Warbler",
                                        "Black-throated Blue Warbler","Black-throated Green Warbler","Black-throated Gray Warbler","Blue-winged Warbler",
                                        "Cape May Warbler","Canada Warbler","Cerulean Warbler","Chestnut-sided Warbler","Colima Warbler","Common Yellowthroat",
                                        "Connecticut Warbler","Golden-cheeked Warbler","Golden-winged Warbler","Grace's Warbler","Hermit Warbler","Hooded Warbler",
                                        "Kentucky Warbler","Kirtland's Warbler","Louisiana Waterthrush","Lucy's Warbler","MacGillivray's Warbler",
                                        "Magnolia Warbler","Mourning Warbler","Nashville Warbler","Northern Parula","Northern Waterthrush","Orange-crowned Warbler",
                                        "Ovenbird","Painted Redstart","Palm Warbler","Pine Warbler","Prairie Warbler","Prothonotary Warbler","Red-faced Warbler",
                                        "Swainson's Warbler","Tennessee Warbler","Townsend's Warbler","Virginia's Warbler","Wilson's Warbler","Worm-eating Warbler",
                                        "Yellow Warbler","Yellow-rumped Warbler","Yellow-throated Warbler")) # list species to process

# warblers matrix
thr_matrix <- read_excel(paste0(boxdir_warblers, 'Warbler Threat Sensitivity Matrix Jul2024.xlsx'), sheet = 5) %>% 
  pivot_longer(cols=-species_name, names_to='threat_name', values_to='impact', values_drop_na = TRUE)

thr_lookup2 <- c('Urban Areas'='X0111_UA',
                'Suburban Areas'='X0112_SA',
                'Agriculture'='X0213_C',
                'Livestock Management'='X0232_L',
                'Oil & Gas Production'='X0311_OG',
                'Wind Turbines'='X0331_WT',
                'Roads'='X0411_R',
                'Communication Towers'='X0422_CT',
                'Forest Management'='X0531_F',
                'Surface Water Management'='X0721_SWM',
                'Light Pollution'='X0961_LP',
                'Drought'='X1141_D')



# migration dates
phen <- fread('Species Lists/bna_ebirdst_seasonal_dates_amended.csv')
phen_long <- data.frame(day_date=seq(as.POSIXct("1000-01-01", format="%Y-%m-%d", tz="GMT"), 
                                     as.POSIXct("1000-12-31", format="%Y-%m-%d", tz="GMT"),1*60*60*24)) %>%
  mutate(yday = yday(day_date), week = ceiling(yday/7)) %>%
  group_by(week) %>% mutate(week_date = first(day_date)) %>% slice(1) %>%
  select(-day_date, -yday) %>% filter(week != 53) %>% 
  mutate(month = month(week_date, label = TRUE)) %>% select(-week_date)

labels <- phen_long %>% arrange(week) %>%
  group_by(month) %>% slice(1) %>% ungroup %>%
  mutate(month_label = as.character(month)) %>% 
  select(-month) 

phen_long <- phen_long %>%
  left_join(labels, by = "week")
rm(labels)


# summarize and plot data
spp_codes <- spp_list$species_code
for (spp_code in spp_codes) {
  
  # get parameters
  spp_name <- filter(spp_list, species_code==spp_code) %>% pull(species_name)
  thr_codes <- filter(thr_matrix, species_name==spp_name) %>% pull(threat_name)
  cat('\n', spp_name)
  
  # file paths
  # run using eBird summaries from 2023
  # spp_path <- paste0('Threat_Data/Summaries/Warblers/Warblers_summarize_threats_Feb2024/Updated_combined_CC_layer_summaries/', spp_code, '_summary_threats_hex', hex_size, '.shp')
  # run using eBird summaries from 2024
    spp_path <- paste0('Migration_Data/Species/',spp_code,"/", spp_code, '_summary_threats_hex', hex_size, '.shp')
  spp_out <- paste0('Threat_Data/Summaries/Warblers/Warblers_summarize_threats_Jul2024/Annual Exposure CSVs/', spp_code, '_exposure_to_conservation_challenges_', hex_size, '.csv')

  if (!file.exists(spp_path)) { cat(': data unavailable\n'); next }
  
  # summarize data
  spp_data <- st_read(spp_path, quiet=TRUE) %>% st_set_geometry(NULL) %>%
    select(week, abund_sum, contains(thr_codes)) %>%
    mutate_at(vars(contains(thr_codes)), ~.*abund_sum) %>%
    group_by(week) %>% summarize_all(sum) %>%
    mutate_at(vars(contains(thr_codes)), ~round(./abund_sum, 3)) %>%
    select(-abund_sum) 
  
  # get seasonal info
  spp_phen <- filter(phen, species_code == spp_code)
  spp_phen_long <- phen_long
  week <- 1:52
  seasons <- rep(NA, nrow(spp_phen_long))
  for(j in 1:nrow(spp_phen)){
    s <- spp_phen[j, ]
    if(s$start_dt <= s$end_dt){ 
      in_season <- week >= s$start_dt & week <= s$end_dt 
    }else{ in_season <- week >= s$start_dt | week <= s$end_dt }
    seasons[in_season] <- s$season
  }
  spp_phen_long <- cbind(spp_phen_long, season=seasons)
  rm(s, seasons)
  
  # join conservation challenges and seasonal data
  spp_data <- spp_data %>%
    full_join(spp_phen_long) %>%
    arrange(week)
  
  # set seasonal conservation challenges to NA during non-migratory periods
  if('X0331_WT' %in% colnames(spp_data)){ spp_data <- spp_data %>% mutate(X0331_WT = ifelse(season == 'winter' | season == 'summer', NA, X0331_WT)) }
  if('X0422_CT' %in% colnames(spp_data)){ spp_data <- spp_data %>% mutate(X0422_CT = ifelse(season == 'winter' | season == 'summer', NA, X0422_CT)) }
  if('X0961_LP' %in% colnames(spp_data)){ spp_data <- spp_data %>% mutate(X0961_LP = ifelse(season == 'winter' | season == 'summer', NA, X0961_LP)) }
  
  # update seasonal terminology
  spp_data <- spp_data %>%
    mutate(season = ifelse(season == 'winter', 'Stationary non-breeding', 
                           ifelse(season == 'spring', 'Pre-breeding migration', 
                                  ifelse(season == 'summer', 'Breeding', 'Post-breeding migration'))))
  
  # write out and plot data
  if(length(spp_data)>3){
    # write spreadsheet
    fwrite(select(spp_data, -month_label), spp_out)
    
    # reformat data for plot
    spp_data_for_plot <- spp_data %>%
      pivot_longer(cols=c(-week, -month, -month_label, -season), names_to='Threat', values_to='Exposure') %>%
      mutate(ExposureClass=cut(Exposure, breaks=c(-1, 0, 0.1, 0.3, 0.7, 1), labels=FALSE),
             ExposureClass=factor(ExposureClass, levels=1:5,
                                  labels=c('None or very low', 'Up to 10%', 'Up to 30%', 'Up to 70%', 'Up to 100% of the population'))) %>%
      left_join(as.data.frame(thr_lookup2) %>% cbind(Threat_Name=names(thr_lookup2)), by=c("Threat"='thr_lookup2'))
    
    # set legend order
    spp_data_for_plot$Threat_Name <- factor(spp_data_for_plot$Threat_Name, 
                                            levels=c("Urban Areas", "Suburban Areas", "Roads", "Light Pollution", 
                                                     "Communication Towers", "Wind Turbines",
                                                     "Oil & Gas Production", "Agriculture", "Livestock Management", 
                                                     "Forest Management", "Surface Water Management", "Drought"))
    
    # define colors
    cc_colors <- c("Urban Areas" = "#3E3E3E", 
                   "Suburban Areas" = "#747474", 
                   "Roads" = "#BBBBBB",
                   "Light Pollution" = "#A70083",
                   "Communication Towers" = "#BC61BF",
                   "Wind Turbines" = "#C999D2",
                   "Oil & Gas Production" = "#1BC48C",#"#004205",
                   "Agriculture" ="#49A776",#"#176F1C", 
                   "Livestock Management" = "#699C36",#"#539241",
                   "Forest Management" = "#ADD149",#"#82B75C", 
                   "Surface Water Management" = "#B4E386",#"#A6D286",
                   "Drought" = "#F3CA01")

    # plot
    spp_plot <- ggplot(data=spp_data_for_plot, aes(x=week, y=Exposure, color=Threat_Name)) +
      # gray shading for prebreeding migration
      annotate('rect', fill='light grey', alpha=.5, ymin = 0, ymax = 1,
               xmin = spp_phen$start_dt[spp_phen$season=='spring'],
               xmax = spp_phen$end_dt[spp_phen$season=='spring']) +
      annotate('text', label = 'Pre-breeding \nMigration',  y=.93, alpha=.2,
               x=((spp_phen$end_dt[spp_phen$season=='spring']-spp_phen$start_dt[spp_phen$season=='spring'])/2)+spp_phen$start_dt[spp_phen$season=='spring']) +
      # gray shading for postbreeding migration
      annotate('rect', fill='light grey', alpha=.5, ymin = 0, ymax = 1,
               xmin = spp_phen$start_dt[spp_phen$season=='fall'],
               xmax = spp_phen$end_dt[spp_phen$season=='fall']) +
      annotate('text', label = 'Post-breeding \nMigration',  y=.93, alpha=.2,
               x=((spp_phen$end_dt[spp_phen$season=='fall']-spp_phen$start_dt[spp_phen$season=='fall'])/2)+spp_phen$start_dt[spp_phen$season=='fall']) +
      # plot data
      geom_line(stat='identity', linewidth=1) +
      # additional labels and formatting
      labs(title=paste0(spp_name), ) + 
      ylab('Percent of Population Exposed') + xlab('') +
      guides(color=guide_legend(title="Conservation Challenge")) +
      scale_color_manual(values=cc_colors, name='') + 
      scale_y_continuous(limits=c(0, 1), labels=scales::percent) +
      scale_x_continuous(expand=c(0.01, 0.01), 
                         breaks = filter(spp_phen_long, !is.na(month_label))$week,
                         labels = filter(spp_phen_long, !is.na(month_label))$month_label) +
      theme_bw() + theme(panel.grid=element_blank(), plot.title=element_text(hjust=0.5))
    
    spp_png <- paste0('Threat_Data/Summaries/Warblers/Warblers_summarize_threats_Jul2024/Annual Exposure Plots/', spp_code, '_all_CCs_', hex_size, '.png')

    # save plot
    ggsave(spp_png, spp_plot, width=8, height=5)
    
  }
  
}


# summarize data by season for analysis
warbler_files <- list.files(paste0('Threat_Data/Summaries/Warblers/Warblers_summarize_threats_Jul2024/Annual Exposure CSVs/'),  
                            paste0('_exposure_to_conservation_challenges_', hex_size, '.csv'))
columns <- c('species', 'season', 'sp_seas', unlist(sort(unique(thr_matrix$threat_name))))
all_data <- data.frame(matrix(nrow=0, ncol=length(columns)))
colnames(all_data) <- columns

for(spp in warbler_files){
  data <- fread(paste0('Threat_Data/Summaries/Warblers/Warblers_summarize_threats_Jul2024/Annual Exposure CSVs/', spp)) %>% 
    mutate(species=strsplit(spp, '_')[[1]][1],
           sp_seas=paste0(species, '_', season)) %>%
    group_by(species, season, sp_seas) %>%
    summarise(across(where(is.numeric), ~sum(.x, na.rm=TRUE))) %>%
    select(-week)

  all_data <- rbind.fill(all_data, data)
}

fwrite(all_data, paste0('Threat_Data/Summaries/Warblers/Warblers_summarize_threats_Jul2024/species_seasonal_sum_', hex_size, '.csv'))

