###This script provides an example for the post-breeding migration analysis
###for Seavy et al. 2025. The script: 
###1.loads the seasonal summaries of the warlber exposure to conservation challenges
###2. Runs and graphs the PCA
###3. Runs the GAMs
###Note that mvstats.R and biostat.R are wrapper functions used in the analysis
###to be places in the working directory
#Bill DeLuca, 27 Sept 2024


##set directory and read in packages
setwd("C:/....")

library(tidyverse)
library(ggplot2)
library(factoextra)
library(corrplot)
library(Hmisc)
library(vegan)
library(ggbiplot)
library(ade4)
library(mgcv)
library(akima)
library(MuMIn)

#source these wrapper scripts from wd
source('biostats.R')
source('mvstats.R')


# read in data
warbler <- read.csv("DataS6_warbler_challenge.csv")

#####################################
##Example for post-breeding migration
#####################################
###format
fall_threats <- warbler %>%
  select(contains("fall"))
colnames(fall_threats)<- gsub("fall_","",colnames(fall_threats))
#add alpha codes back in
fall_threats <- cbind(warbler$alpha, fall_threats)
colnames(fall_threats)[1] <- "species"
fall_threats <- fall_threats %>% column_to_rownames(var="species")

###correlation
cor <- cor(fall_threats)
corrplot(cor, method="color", tl.col = "black",
         title = "Postbreeding migration",
         mar = c(0,0,1,0), number.cex = 0.5, number.digits = 2)
#see correlation coefficients
cor2 <- rcorr(as.matrix(threats))

###PCA
fallpca <- prcomp(fall_threats, scale=TRUE)
summary(fallpca)
#examine PCA results and conduct Monte Carlo
pca.eigenval(fallpca)
pca.eigenvec(fallpca, dim=5, digits = 3, cutoff = .2)
montefall <- ordi.monte(fall_threats, ord = "pca")
structurefall <- pca.structure(fallpca, fall_threats, dim=3, cutoff=0.3)

#biplot
fviz_pca_biplot(fallpca, label="all", repel=TRUE, 
                axes = c(1,2),
                #habillage = reduce$alpha,
                select.var= list(contrib=10),
                #col.ind = "steelblue",
                col.ind = reduce$trendCat, palette = c("#994455","#004488","#EE99AA","#6699CC"),
                addEllipses = FALSE, ellipse.level = 0.7,
                pointsize = 3,
                labelsize = 4,
                col.var = "dark gray",
                arrowsize = 1,
                jitter = list(what = "label", width = 20, height = 10),
                axes.linetype = "blank",
                xlab = "PC1 (30.9%)", ylab = "PC2 (22.7%)", 
                title="Postbreeding Migration",
                legend.title = "Trend catagory", #Breeding distribution",
                geom = c("text")) + theme_classic()+
  theme(legend.text = element_text(size = 12), legend.title = element_text(size=12, face="bold"), 
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 12, face="bold"),
        plot.title = element_text(size = 15, face="bold"), legend.position = "none")


###Generalized Additive Models - GAMs
#format
fallx <- fallpca$x
fallgam <- cbind(warbler,fallx) %>% 
  select(c("trend", "species", "alpha", "PC1", "PC2", "PC3")) 

#run run GAM and see results
m1 <- gam(trend~s(PC1)+s(PC2), data=fallgam)
summary(m1)

